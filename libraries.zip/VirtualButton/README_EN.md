This is an automatic translation, may be incorrect in some places. See sources and examples!

Cranberry# VirtualButton
 Library with button processing logic (virtual button) for Arduino